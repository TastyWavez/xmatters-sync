import React from 'react';

const App = () => {
    return (
        <span
            title="This is an advanced configuration and is not required in many cases."
            className="badge badge-pill bg-xm-blue text-xm-lightergrey mr-1 align-middle"
        >
            Advanced
        </span>
    );
};

export default App;
